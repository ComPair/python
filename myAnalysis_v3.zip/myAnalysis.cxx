#include "MyAnalyzer.h"
#include "Storage.h"

#include <iostream>
#include <string>

#include <unistd.h>
#include <stdlib.h>
#include <getopt.h>


#include "MGlobal.h"
#include "MRERawEvent.h"
#include "MSimEvent.h"


void print_usage(const char* progname) {
  std::cout<<"Usage: "<<progname<<" -g geomfile -s simfile <-c cfgfile> <-r root_outfile> <-t tra_outfile> <-h>"<<std::endl;
}

void test_input_file(const string fname, const string filetype) {
  if (fname.size()==0) {
    std::cerr<<"ERROR: input "<<filetype<<" is mandatory!"<<std::endl;
    exit(-1);
  }
  if (access(fname.c_str(), R_OK )!=0) {
    std::cerr<<"ERROR: cannot access "<<fname<<std::endl;
    exit(-1);
  }
}

bool test_output_file(const string fname) {
  if (fname.size()==0) 
    return false; //ok
  if (access(fname.c_str(), R_OK )==0) {
    std::cerr<<"WARNING: file "<<fname<<" exists and will be overwritten, press Ctrl-C to abort, any key to continue"<<std::endl;
    getchar();
    return true;
  }
  return true;
}



int main(int argc, char **argv) {

  string cfg_fname(""),
    geo_fname(""),
    sim_fname(""),
    tra_fname(""),
    root_fname("");
  int maxn=-1;

  //process command line

  while (true){
    int c = getopt(argc, argv, "c:s:g:t:r:n:h");

    if (c==-1)
      break; //end of options

    switch(c) {
    case 'c':
      cfg_fname=optarg;
      break;
    case 's':
      sim_fname=optarg;
      break;
    case 'g':
      geo_fname=optarg;
      break;
    case 't':
      tra_fname=optarg;
      break;
    case 'r':
      root_fname=optarg;
      break;
    case 'n':
      maxn=atoi(optarg);
      break;
    case 'h':
    case '?':
    default:
      print_usage(argv[0]);
      exit(0);
      break;
    }    
  }

  //check parameters and files
  test_input_file(geo_fname,"geometry file (-g)");
  test_input_file(sim_fname,"sim file (-s)");
  test_input_file(cfg_fname,"revan cfg file (-c)");
  bool is_tra=test_output_file(tra_fname);
  bool is_root=test_output_file(root_fname);
  bool is_maxn=(maxn>0);

  //"/data/glast/analysis/berlato/megalib/tests/stdmod/detector.geo.setup"
  //"/data/glast/analysis/berlato/megalib/tests/stdmod/4000kev/4000kev.p1.sim"
  //"/data/glast/analysis/rick/megalib/tests/this_revan.cfg"

  MyAnalyzer* ana = new MyAnalyzer(geo_fname.c_str(),sim_fname.c_str());
  ana->readConfig(cfg_fname.c_str());
  if (is_tra)
    ana->outputTra(tra_fname.c_str());
  if (is_maxn)
    ana->setMaxEvno(maxn);

  Storage* store;

  MRERawEvent* rawe;
  MSimEvent* sime;
  if (is_root) {
    store = new Storage(geo_fname.c_str(),root_fname.c_str());
    //set up square ring regions
    //setup_SQR(progressive_id, x_and_y_min, x_and_y_max, z_min, z_max);

    //TKR
    store->setup_SQR(0, 0.,3.701, 0., 8.);
    //CAL: BOTTOM
    store->setup_SQR(1, 0.,3.771, -6., 0.);
    //CAL: SIDES
    store->setup_SQR(2, 3.701, 5., -2., 8.);
    //CAL: BOTTOM, EXTERNAL XTALS ONLY
    store->setup_SQR(3, 2.75, 3.771, -6., 0.);
  }


  while (ana->next()) {
    if (is_root) {
      rawe=ana->getRawEvent();
      sime=ana->getSimEvent();
      sime->Analyze();
      store->store(rawe,sime);
      //if (rawe->GetEventType()==MRERawEvent::c_PairEvent) {
      //store->store_pair(dynamic_cast<MPairEvent*>(rawe->GetPhysicalEvent()),
      //		 sime);
      //} else if (rawe->GetEventType()==MRERawEvent::c_ComptonEvent) {
      //store->store_compton(dynamic_cast<MComptonEvent*>(rawe->GetPhysicalEvent()),
      //		    sime);
    } // if is_root
    ana->cleanup();
  } //while events

  std::cout<<"Processed "<<ana->getCount()<<" events"<<std::endl;

  if (is_root)
    delete store;
  delete ana;
  return 0;
}
