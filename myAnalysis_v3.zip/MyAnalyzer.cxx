#include "MyAnalyzer.h"


#include "MPhysicalEvent.h"
#include "MRESE.h"
#include "MRETrack.h"
#include "MSettingsRevan.h"
#include "MSettingsEventReconstruction.h"
#include "MComptonEvent.h"
#include "MPairEvent.h"

#include <iostream>


// private:
//  MGeometryRevan* m_geom;
//  MFileEventsSim* m_sim;
//  MRawEventAnalyzer* m_analyzer;
//  Storage* m_store;
//  int m_id,m_simid;


MyAnalyzer::MyAnalyzer(const char *geom_fname, const char* sim_fname) {

  m_geom=new MGeometryRevan();
  m_geom->ScanSetupFile(geom_fname);

  m_sim=new MFileEventsSim(m_geom);  
  m_sim->Open(sim_fname);

  m_analyzer = new MRawEventAnalyzer();
  m_analyzer->SetGeometry(m_geom);
  m_analyzer->SetInputModeFile(sim_fname);

  
  m_analyzer->SetBatch(true);
  m_io_stdio=false;
  m_io_tra=false;
  m_io_root=false; 

  m_maxno=-1; //all events
  m_counter=0;

  m_notpre=true; //must run preanalysis
}

MyAnalyzer::~MyAnalyzer() {
  if (!m_analyzer->PostAnalysis()) {
    std::cout<<"Post-analysis fail"<<std::endl;  
  }
  delete m_analyzer;
  delete m_sim;
  delete m_geom;  
}


void MyAnalyzer::setMaxEvno(const int n) {
  m_maxno=n;
}


void MyAnalyzer::outputSdtio(const bool enable) {
  m_io_stdio=enable;
}



void MyAnalyzer::outputTra(const char* tra_fname) {
  m_io_tra=true;
  m_analyzer->SetOutputModeFile(tra_fname);
}

void MyAnalyzer::readConfig(const char* cfg_fname) {
  MSettingsRevan *settings=new MSettingsRevan();
  settings->Read(cfg_fname);
  m_analyzer->SetSettings(dynamic_cast<MSettingsEventReconstruction*>(settings));
  m_notpre=true;
}

bool MyAnalyzer::next() {
  unsigned int rc;
  if (m_notpre) {
    //first ever
    if (!m_analyzer->PreAnalysis()) {
      std::cout<<"Pre-analysis fail"<<std::endl;  
    }
    m_notpre=false;
  }
  
    
  while ((m_maxno<0)||(m_counter<m_maxno)) {
    rc=m_analyzer->AnalyzeEvent();
    if (rc==MRawEventAnalyzer::c_AnalysisNoEventsLeftInFile) {
      std::cout<<"No more events to analyze"<<std::endl;
      return false;
    }
    if (rc!=MRawEventAnalyzer::c_AnalysisSucess) {
      std::cout<<"Analysis error!"<<std::endl;
      return false;
    } else {
      //all ok
      m_RE = m_analyzer->GetOptimumEvent();
      if (m_RE != 0) {
	m_id=m_RE->GetEventID();
	//advance SIM	  
	while (true) {
	  m_sim_ev=m_sim->GetNextEvent(false);
	  m_simid=m_sim_ev->GetID();
	  if (m_simid<m_id) {
	    //std::cout<<"Advance: id "<<m_simid<<" evt ID "<<m_id<<std::endl;
	    delete m_sim_ev;
	  } else if (m_simid==m_id) {
	    //std::cout<<"SIM id match"<<m_simid<<" evt ID "<<m_id<<std::endl;
	    break;
	  } else { //m_simid>m_id
	    std::cout<<"Mismatch SIM id "<<m_simid<<" evt ID "<<m_id<<" ... file change?"<<std::endl;
	    //probably we switched file, advance sim id
	    
	    //delete m_sim_ev;
	    return true; //exit without error
	  }	    
	} //while advance sim
	if (m_simid!=m_id) {
	  std::cout<<"Something went wrong, SIM id mismatch"<<m_simid<<" evt ID "<<m_id<<std::endl;
	  //something went wrong, stop and save
	  return false; 
	}
	//last check
	if (m_RE->GetPhysicalEvent() == 0) {
	  std::cout<<"No physical event"<<std::endl;
	  return false;
	}
	m_counter++;
	return true;
      } //if optimum event    
    } //if analysis ok
  }
  //max event count stored
  return false; 
}

void MyAnalyzer::cleanup() {
  if (m_sim_ev!= 0)
    delete m_sim_ev;
  //if (m_RE!= 0)
  //  delete m_RE;
}

MRERawEvent* MyAnalyzer::getRawEvent() {
  return m_RE;
}

MSimEvent* MyAnalyzer::getSimEvent() {
  return m_sim_ev;
}

int MyAnalyzer::getCount() {
  return m_counter;
}
