#include "Storage.h"
#include <math.h>
#include <iostream>
#include <sstream>

#include "MRETrack.h"
#include "MREHit.h"

Storage::Storage(const char* geomfilename,const char *outfilename) {
  //std::cout<<"Init Storage"<<std::endl;
  //init stuff
  m_geom=new MyGeometryQuest(geomfilename);
  m_rootfile=new TFile(outfilename,"RECREATE");
  m_cotree=new TTree("Compton","Compton");
  m_pptree=new TTree("Pair","Pair");
  TTree* trees[]={m_cotree,m_pptree};
  //set storage
  ostringstream oss;
  string s1,s2;
  // variable common to all events
  for (int i=0;i<2;i++) {

    //basic event info
    trees[i]->Branch("ID",&m_id,"ID/I");
    trees[i]->Branch("ProgID",&m_prog_id,"ProgID/I");
    trees[i]->Branch("Time",&m_time,"Time/D");
    trees[i]->Branch("Position",&m_edep_pos,"Position[3]/D");
    //MC vars
    trees[i]->Branch("McEnergy",&m_ene_mc,"McEnergy/D");
    trees[i]->Branch("McEneErr",&m_ene_err,"McEneErr/D");
    trees[i]->Branch("McRelEneErr",&m_rel_ene_err,"McRelEneErr/D");
    trees[i]->Branch("McDirection",&m_dir_mc,"McDirection[3]/D");
    trees[i]->Branch("McType",&m_mc_process,"McType/I");
    trees[i]->Branch("McEnergyD1",&m_mc_ene_D1,"McEnergyD1/D");
    trees[i]->Branch("McEnergyD2",&m_mc_ene_D2,"McEnergyD2/D");
    //energy and energy per detector/region
    trees[i]->Branch("Energy",&m_ene,"Energy/D");
    trees[i]->Branch("EnergyD1",&m_ene_D1,"EnergyD1/D");
    trees[i]->Branch("EnergyD2",&m_ene_D2,"EnergyD2/D");					      
    // MC energy depositions
    // ################ UGLY, fix this
    for (int j=0;j<NSQR;j++) {
      oss.str("");
      oss<<"McEnergySQR"<<j;
      s1=oss.str();
      oss<<"/D";
      s2=oss.str();
      trees[i]->Branch(s1.c_str(),&(m_mc_ene_SQR[j]), s2.c_str());
      m_mc_ene_SQR[j]=0;
    }
    for (int j=0;j<NSQR;j++) {
      oss.str("");
      oss<<"McNHitSQR"<<j;
      s1=oss.str();
      oss<<"/I";
      s2=oss.str();
      trees[i]->Branch(s1.c_str(),&(m_mc_n_SQR[j]), s2.c_str());
      m_mc_n_SQR[j]=0;
    }
    for (int j=0;j<NSQR;j++) {
      oss.str("");
      oss<<"McMaxEHitSQR"<<j;
      s1=oss.str();
      oss<<"/D";
      s2=oss.str();
      trees[i]->Branch(s1.c_str(),&(m_mc_max_ene_SQR[j]), s2.c_str());
      m_mc_max_ene_SQR[j]=0;
    }
    // raw event energy depositions
    // ################ UGLY, fix this
    for (int j=0;j<NSQR;j++) {
      oss.str("");
      oss<<"EnergySQR"<<j;
      s1=oss.str();
      oss<<"/D";
      s2=oss.str();
      trees[i]->Branch(s1.c_str(),&(m_ene_SQR[j]), s2.c_str());
      m_mc_ene_SQR[j]=0;
    }
    for (int j=0;j<NSQR;j++) {
      oss.str("");
      oss<<"NHitSQR"<<j;
      s1=oss.str();
      oss<<"/I";
      s2=oss.str();
      trees[i]->Branch(s1.c_str(),&(m_n_SQR[j]), s2.c_str());
      m_mc_n_SQR[j]=0;
    }
    for (int j=0;j<NSQR;j++) {
      oss.str("");
      oss<<"MaxEHitSQR"<<j;
      s1=oss.str();
      oss<<"/D";
      s2=oss.str();
      trees[i]->Branch(s1.c_str(),&(m_max_ene_SQR[j]), s2.c_str());
      m_mc_max_ene_SQR[j]=0;
    }    

  }
  //------------ COMPTON SPECIFIC ----------------

  //additional vars using MC information
  m_cotree->Branch("McPhi",&m_co_mcphi,"McPhi/D");

  //event structure and quality
  m_cotree->Branch("HasTrack",&m_co_hastr,"HasTrack/I");
  m_cotree->Branch("SequenceLength",&m_co_seql,"SequenceLength/I");
  m_cotree->Branch("TrackLength",&m_co_trl,"TrackLength/I");
  m_cotree->Branch("ComptonQF",&m_co_cqf,"ComptonQF/D");
  m_cotree->Branch("TrackQF",&m_co_tqf,"TrackQF/D");
  m_cotree->Branch("LeverArm",&m_co_leverarm,"LeverArm/D");

  //angles
  m_cotree->Branch("DirectionG",&m_co_dg,"DirectionG[3]/D");
  m_cotree->Branch("DirectionE",&m_co_de,"DirectionE[3]/D");
  m_cotree->Branch("Theta",&m_co_theta,"Theta/D");
  m_cotree->Branch("Epsilon",&m_co_epsilon,"Epsilon/D");
  m_cotree->Branch("Phi",&m_co_phi,"Phi/D");
  m_cotree->Branch("PhiErr",&m_co_dphi,"PhiErr/D");

  //energies
  m_cotree->Branch("PositionC1",&m_co_c1,"PositionC1[3]/D");
  m_cotree->Branch("PositionC2",&m_co_c2,"PositionC2[3]/D");
  m_cotree->Branch("Eg",&m_co_eg,"Eg/D");
  m_cotree->Branch("EgErr",&m_co_deg,"EgErr/D");
  m_cotree->Branch("Ee",&m_co_ee,"Ee/D");
  m_cotree->Branch("EeErr",&m_co_dee,"EeErr/D");
  m_cotree->Branch("EnergyErr",&m_co_dei,"EnergyErr/D");

  //resolution elements
  m_cotree->Branch("ARM",&m_co_arm,"ARM/D");
  m_cotree->Branch("SPD",&m_co_spd,"SPD/D");
  

  //additional vars, high level analysis making use of events' details

  //probability of absoprtion, along scattered gamma track (C1 to C2)
  m_cotree->Branch("ProbAbsorptionAlong",&m_co_trk_absprob,"ProbAbsorptionAlong/D");
  //probability of absoprtion, ahead of scattered gamma track (C2 to infinity)
  m_cotree->Branch("ProbAbsorptionExtToC2",&m_co_c2_absprob,"ProbAbsorptionExtToC2/D");
  //probability of absoprtion, reverse of scattered gamma track (C1 to infinity)
  m_cotree->Branch("ProbAbsorptionExtToC1",&m_co_c1_absprob,"ProbAbsorptionExtToC1/D");
  //radiation lengths between C1 and C2
  m_cotree->Branch("RLsBetweenC1C2",&m_co_rl_along,"RLsBetweenC1C2/D");
  //radiatione lengths after C2, along scattered gamma direction
  m_cotree->Branch("RLsExtToC2",&m_co_rl_c2,"RLsExtToC2/D");
  //radiatione lengths before C1, along scattered gamma direction
  m_cotree->Branch("RLsC1ToExt",&m_co_rl_c1,"RLsC1ToExt/D");

  m_cotree->Branch("NadirReach",&m_co_nadirmax,"NadirReach/D");
  m_cotree->Branch("NadirReachRev",&m_co_nadirmax_rev,"NadirReachRev/D");

  //------------ PAIR SPECIFIC ----------------
  m_pptree->Branch("Aperture",&m_pp_angle,"Aperture/D");

  m_pptree->Branch("Direction",&m_pp_dir,"Direction[3]/D");
  m_pptree->Branch("TrackQF",&m_pp_tqf,"TrackQF/D");
  m_pptree->Branch("PositronDir",&m_pp_p_dir,"PositronDir[3]/D");
  m_pptree->Branch("ElectronDir",&m_pp_e_dir,"ElectronDir[3]/D");
  m_pptree->Branch("Ep",&m_pp_e_p,"Ep/D");
  m_pptree->Branch("EpErr",&m_pp_e_p_err,"EpErr/D");
  m_pptree->Branch("Ee",&m_pp_e_e,"Ee/D");
  m_pptree->Branch("EeErr",&m_pp_e_e_err,"Ee/D");


  m_pptree->Branch("DirErr",&m_pp_dir_err,"DirErr/D");


  //some initialization
  m_prog_id=0;
  for (unsigned int k=0;k<NSQR;k++) 
    setup_SQR(k, 0.,0.,0.,0.);
  //std::cout<<"done"<<std::endl;
}

Storage::~Storage() {
  //std::cout<<"Close Storage"<<std::endl;
  delete m_geom;
  m_cotree->Write();
  m_pptree->Write();
  m_rootfile->Close();
  m_rootfile->Delete();
  //std::cout<<"done"<<std::endl;

}


int Storage::setup_SQR(unsigned int sqrno, double xymin, double xymax,double zmin, double zmax) {
  if (sqrno>=NSQR) {
    std::cerr<<"setup_SQR: SQR region > NSQR : "<<sqrno<<std::endl;
    return -1;
  }
  //std::cout<<"setup SQR "<<sqrno<<" "<<xymin<<" "<<xymax<<" "<<zmin<<" "<<zmax<<std::endl;
  m_def_SQR_xymin[sqrno]=xymin;
  m_def_SQR_xymax[sqrno]=xymax;
  m_def_SQR_zmin[sqrno]=zmin;
  m_def_SQR_zmax[sqrno]=zmax;
  return 1;
}


int Storage::store(MRERawEvent* rawevt, MSimEvent* simevt) {

  if (rawevt->GetEventType()==MRERawEvent::c_ComptonEvent) {
    m_curtree=m_cotree;
  } else if (rawevt->GetEventType()==MRERawEvent::c_PairEvent) {
    m_curtree=m_pptree;
  }  else {
    return 1; //ignore
  }

  setup_common(rawevt, simevt);

  if (rawevt->GetEventType()==MRERawEvent::c_ComptonEvent) {
    setup_compton(dynamic_cast<MComptonEvent*>(rawevt->GetPhysicalEvent()),simevt);
  } else { //if (rawevt->GetEventType()==MRERawEvent::c_PairEvent) {
    setup_pair(dynamic_cast<MPairEvent*>(rawevt->GetPhysicalEvent()),simevt);
  }
  
  m_curtree->Fill();
  return 0;
}

int Storage::setup_common(MRERawEvent* rawevt, MSimEvent* simevt) {
  MPhysicalEvent* evt=rawevt->GetPhysicalEvent();
  //all
  m_id=evt->GetId();
  m_ene=evt->GetEnergy();
  m_time=evt->GetTime().GetAsDouble();
  m_tmpvec=evt->GetPosition();
  for (int i=0;i<3;i++)
    m_edep_pos[i]=m_tmpvec[i];
  m_prog_id++;
  
  //MC
  /*
  if (simevt==0) {
    m_ene_mc=-1;
    m_rel_ene_err=-999;
    m_ene_err=0;
    m_dir_mc[0]=0.;
    m_dir_mc[1]=0.;
    m_dir_mc[2]=0.;    
    m_co_arm=180.;
  } else {
  */
  m_ene_mc=simevt->GetICEnergy();
  m_rel_ene_err=1-m_ene/m_ene_mc;
  m_ene_err=m_ene-m_ene_mc;
  
  m_mcdir=simevt->GetICOrigin();
  for (int i=0;i<3;i++)
    m_dir_mc[i]=m_mcdir[i];   //mcdir is filled
  //m_co_arm=evt->GetARMGamma(m_tmpvec*(-c_FarAway))*c_Deg;
  m_mc_process=simevt->GetEventType();

  //reset all incremental variables to 0
  m_ene_D1=0;  m_ene_D2=0;
  m_mc_ene_D1=0;  m_mc_ene_D2=0;
  for (unsigned int k=0;k<NSQR;k++) {
    m_mc_ene_SQR[k]=0;  
    m_mc_n_SQR[k]=0;  
    m_mc_max_ene_SQR[k]=0;
    m_ene_SQR[k]=0;  
    m_n_SQR[k]=0;  
    m_max_ene_SQR[k]=0;
  }
  

  //number of hits, energy, max energy for MC event
  MSimHT* hit;
  for (unsigned i = 0; i < simevt->GetNHTs(); ++i) {
    hit=simevt->GetHTAt(i);
    if (hit->GetEnergy()==0.) 
      continue;
    if (hit->GetDetector()==1)
      m_mc_ene_D1+=hit->GetEnergy();
    if (hit->GetDetector()==2)
      m_mc_ene_D2+=hit->GetEnergy();
    for (unsigned int k=0;k<NSQR;k++) {
      if (in_SQR(k,hit->GetPosition())) {
	m_mc_n_SQR[k]+=1;
	m_mc_ene_SQR[k]+=hit->GetEnergy();
	if (m_mc_max_ene_SQR[k]<hit->GetEnergy())
	  m_mc_max_ene_SQR[k]=hit->GetEnergy();
      }
    } //for k in NSQR
  } // for i in hits
  

  
  //number of hits, energy, max energy for raw event
  MRETrack* track;
  MRESE* RESE;
  for (int i = 0; i < rawevt->GetNRESEs(); ++i) {
    RESE = rawevt->GetRESEAt(i);
    if (RESE->GetType() == MRESE::c_Track) { 
      track=(MRETrack*)RESE;
      for (int h = 0; h < track->GetNRESEs(); ++h) {
	RESE = track->GetRESEAt(h);
	//track hit
	if (RESE->GetDetector()==1) {
	  m_ene_D1+=RESE->GetEnergy();
	}
	else { //RESE->GetDetector()==2
	  m_ene_D2+=RESE->GetEnergy();	  
	}
	for (unsigned int k=0;k<NSQR;k++) {
	  if (in_SQR(k,RESE->GetPosition())) {
	    m_n_SQR[k]+=1;
	    m_ene_SQR[k]+=RESE->GetEnergy();
	    if (m_max_ene_SQR[k]<RESE->GetEnergy())
	      m_max_ene_SQR[k]=RESE->GetEnergy();
	  } // if in SQR
	} // for k in RESEs
      } //for h track RESE
    } else if ((RESE->GetType() == MRESE::c_Hit)||(RESE->GetType() == MRESE::c_Cluster)) {
      //single hit/cluster
      if (RESE->GetDetector()==1) {
	m_ene_D1+=RESE->GetEnergy();
      }
      else {//RESE->GetDetector()==2
	m_ene_D2+=RESE->GetEnergy();	
      }
      for (unsigned int k=0;k<NSQR;k++) {
	if (in_SQR(k,RESE->GetPosition())) {
	  m_n_SQR[k]+=1;
	  m_ene_SQR[k]+=RESE->GetEnergy();
	  if (m_max_ene_SQR[k]<RESE->GetEnergy())
	      m_max_ene_SQR[k]=RESE->GetEnergy();
	} //is in SQR
      } //for k in RESEs
    } //if rese is type
  } //for RESE
  

  return 0;

}


int Storage::setup_compton(MComptonEvent* evt, MSimEvent* simevt) {
  
  //compton
  m_gammadir=evt->Dg();
  for (int i=0;i<3;i++)
    m_co_dg[i]=m_gammadir[i]; //gammadir is filled
  //fill MC phi
  m_co_mcphi=m_mcdir.Angle(m_gammadir);
  m_tmpvec=evt->De();
  for (int i=0;i<3;i++)
    m_co_de[i]=m_tmpvec[i];
  m_co_dei=evt->dEi();
  m_co_seql=evt->SequenceLength();
  m_co_hastr=evt->HasTrack();
  m_co_trl=evt->TrackLength();
  m_co_theta=evt->Theta();
  m_co_phi=evt->Phi(); 
  m_co_dphi=evt->dPhi();
  m_co_epsilon=evt->Epsilon();
  m_co_eg=evt->Eg();
  m_co_deg=evt->dEg();
  m_co_ee=evt->Ee();
  m_co_dee=evt->dEe();
  m_co_cqf=evt->ComptonQualityFactor1();
  m_co_tqf=evt->TrackQualityFactor1();
  m_co_leverarm=evt->LeverArm();
  m_tmpvec=evt->C1();
   for (int i=0;i<3;i++)
     m_co_c1[i]=m_tmpvec[i];
  m_tmpvec=evt->C2();
   for (int i=0;i<3;i++)
     m_co_c2[i]=m_tmpvec[i];
   //MC
   m_tmpvec=simevt->GetICOrigin();
   for (int i=0;i<3;i++)
      m_dir_mc[i]=m_tmpvec[i];   
   m_co_arm=evt->GetARMGamma(m_tmpvec*(-c_FarAway))*c_Deg;
   m_co_spd=evt->GetSPDElectron(m_tmpvec*(-c_FarAway))*c_Deg;


   

  //additional vars
   //abs prob along scattered gamma track
   m_co_trk_absprob=m_geom->GetAbsorptionProbability(evt->C1(),evt->C2(),evt->GetEnergy());
   //abs prob from C2 to infinity
   m_co_c2_absprob=m_geom->GetAbsorptionProbabilityAhead(evt->C1(),evt->C2(),evt->GetEnergy(),false);
   //abs prob from infinity to C1
   m_co_c1_absprob=m_geom->GetAbsorptionProbabilityAhead(evt->C1(),evt->C2(),evt->GetEnergy(),true);
   //radiation lengths between C1 and C2 along scattered gamma direction
   m_co_rl_along=m_geom->GetRLTraversed(evt->C1(),evt->C2());
   //radiation lengths after C2 along scattered gamma direction
   m_co_rl_c1=m_geom->GetRLAhead(evt->C1(),evt->C2(),false);
   //radiation lengths before C1 along scattered gamma direction
   m_co_rl_c2=m_geom->GetRLAhead(evt->C1(),evt->C2(),true);

   //earth limb
   m_co_nadirmax=(M_PI-acos(m_co_dg[2])+m_co_phi)*180./M_PI;
   m_co_nadirmax_rev=(acos(m_co_dg[2])+m_co_phi)*180./M_PI;
  
  return 0;
}

int Storage::setup_pair(MPairEvent* evt, MSimEvent* simevt) {
 
  //pair
  
  m_pp_angle=evt->GetOpeningAngle();

  m_tmpvec=evt->GetOrigin();
  for (int i=0;i<3;i++)
    m_pp_dir[i]=m_tmpvec[i];

  m_tmpvec=evt->GetPositronDirection();
  for (int i=0;i<3;i++)
    m_pp_p_dir[i]=m_tmpvec[i];

  m_tmpvec=evt->GetElectronDirection();
  for (int i=0;i<3;i++)
   m_pp_e_dir[i]=m_tmpvec[i];
  
  m_pp_tqf=evt->GetTrackQualityFactor();
  m_pp_e_e=evt->GetEnergyElectron();
  m_pp_e_p=evt->GetEnergyPositron();
  m_pp_e_e_err=evt->GetEnergyErrorElectron();
  m_pp_e_p_err=evt->GetEnergyErrorPositron();

  //MC
   m_tmpvec=simevt->GetICOrigin();
   for (int i=0;i<3;i++)
      m_dir_mc[i]=m_tmpvec[i];   
   m_pp_dir_err=evt->GetARMGamma(m_tmpvec*(-c_FarAway))*c_Deg;


  return 0;

}

bool Storage::in_SQR(const int SQRid, const MVector pos) const {
  Double_t xx(fabs(pos.X()));
  Double_t yy(fabs(pos.Y()));
  Double_t z(pos.Z());
  if (SQRid<NSQR) {
    if (z>=m_def_SQR_zmin[SQRid] && z<=m_def_SQR_zmax[SQRid])
      if ( (xx>=m_def_SQR_xymin[SQRid] && xx<=m_def_SQR_xymax[SQRid] && yy<=m_def_SQR_xymax[SQRid]) || (yy>=m_def_SQR_xymin[SQRid] && yy<=m_def_SQR_xymax[SQRid] && xx<=m_def_SQR_xymax[SQRid]) )
	return true;
  }
  return false;
}
