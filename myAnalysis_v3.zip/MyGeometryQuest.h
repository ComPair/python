#ifndef __MyGeometryQuest__
#define __MyGeometryQuest__

#include "MGlobal.h"
#include "MDGeometryQuest.h"

class MyGeometryQuest : public MDGeometryQuest
{
  public:
  MyGeometryQuest(const char* filename);
  ~MyGeometryQuest();

  double GetAbsorptionProbabilityAhead(MVector start,MVector stop,double energy, bool reverse=false );
  double GetRLAhead(MVector start,MVector stop, bool reverse=false );
  double GetRLTraversed(MVector start,MVector stop);
  
};


#endif //__MyGeometryQuest__
