#include "MyGeometryQuest.h"


MyGeometryQuest::MyGeometryQuest(const char* filename) {
  ScanSetupFile(filename);
  
}

MyGeometryQuest::~MyGeometryQuest() {}


double MyGeometryQuest::GetAbsorptionProbabilityAhead(MVector start,MVector stop,double energy, bool reverse) {
  MVector tmpvec=(stop-start).Unit(); //direction of track
  tmpvec*=2*GetStartSphereRadius(); //bring to outside
  if (reverse)
    return GetAbsorptionProbability(start,start-tmpvec,energy);
  //else
  return GetAbsorptionProbability(stop,stop+tmpvec,energy);

}

double MyGeometryQuest::GetRLAhead(MVector start,MVector stop, bool reverse) {
  map<MDMaterial*, double> Lengths;
  map<MDMaterial*, double>::iterator LengthsIter;
  double rl=0.;
  
  MVector tmpvec=(stop-start).Unit(); //direction of track
  tmpvec*=2*GetStartSphereRadius(); //bring to outside
  
  if (reverse) {
    GetWorldVolume()->GetAbsorptionLengths(Lengths, start,start-tmpvec);
  } else {
    GetWorldVolume()->GetAbsorptionLengths(Lengths, stop,stop+tmpvec);
  }


  for (LengthsIter = (Lengths.begin()); 
       LengthsIter != Lengths.end(); LengthsIter++) {

    if ((*LengthsIter).second < 0) {
      //ignore (error?)
      continue;
    }
    rl+=(*LengthsIter).second/(*LengthsIter).first->GetRadiationLength();
    /*
    std::cout<<" Mat: "<<(*LengthsIter).first->GetName()
	     <<" Length: "<<(*LengthsIter).second
	     <<"r.l.: "<<(*LengthsIter).first->GetRadiationLength()
	     <<std::endl;;
    */
  } // for LengthsIter

  return rl;

}

double MyGeometryQuest::GetRLTraversed(MVector start,MVector stop) {
  map<MDMaterial*, double> Lengths;
  map<MDMaterial*, double>::iterator LengthsIter;
  double rl=0.;
  
  GetWorldVolume()->GetAbsorptionLengths(Lengths, start,stop);

  for (LengthsIter = (Lengths.begin()); 
       LengthsIter != Lengths.end(); LengthsIter++) {

    if ((*LengthsIter).second < 0) {
      //ignore (error?)
      continue;
    }
    rl+=(*LengthsIter).second/(*LengthsIter).first->GetRadiationLength();


  } // for LengthsIter

  return rl;

}
