#ifndef __MyAnalyzer__
#define __MyAnalyzer__

#include "MGlobal.h"
#include "MSimEvent.h"
#include "MGeometryRevan.h"
#include "MRawEventAnalyzer.h"
#include "MFileEventsSim.h"
#include "MRERawEvent.h"
#include "MSimEvent.h"


class MyAnalyzer {
 public:
  MyAnalyzer(const char *geom_fname, const char* sim_fname);
  ~MyAnalyzer();
  void outputSdtio(const bool enable=true);
  void outputTra(const char* tra_fname);
  void readConfig(const char* cfg_fname);
  bool next();
  void cleanup();
  MRERawEvent* getRawEvent();
  MSimEvent* getSimEvent();
  void setMaxEvno(const int n=-1);
  int getCount();
 private:
  MGeometryRevan* m_geom;
  MFileEventsSim* m_sim;
  MRawEventAnalyzer* m_analyzer;
  int m_id,m_simid,m_maxno,m_counter;
  bool m_io_stdio, m_io_tra, m_io_root;
  MRERawEvent* m_RE;
  MSimEvent* m_sim_ev;
  bool m_notpre;
};




#endif //__MyAnalyzer__
