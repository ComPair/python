#ifndef __Storage__
#define __Storage__

#define NSQR 4

#include "MGlobal.h"
#include "MRERawEvent.h"
#include "MComptonEvent.h"
#include "MPairEvent.h"
#include "MSimEvent.h"
#include "MyGeometryQuest.h"
#include "MSimHT.h"
#include "TROOT.h"
#include "TTree.h"
#include "TFile.h"

class Storage {
 public:
  Storage(const char* geomfilename, const char *outfilename);
  ~Storage();
  int setup_SQR(unsigned int sqrno, double xymin, double xymax,double zmin, double zmax);
  int store(MRERawEvent*, MSimEvent*);
 private:
  int setup_common(MRERawEvent*, MSimEvent*);
  int setup_compton(MComptonEvent*, MSimEvent*);
  int setup_pair(MPairEvent*, MSimEvent*);
  bool in_SQR(const int SQRid,const MVector pos) const;

  TFile *m_rootfile;
  TTree *m_cotree,*m_pptree,*m_curtree;
  MyGeometryQuest* m_geom;
  //branches
  //all
  Int_t m_id,m_prog_id;
  Double_t m_ene,m_ene_mc,m_time,m_ene_err,m_rel_ene_err;
  Double_t m_edep_pos[3],m_dir_mc[3];
  Double_t m_ene_D1,m_ene_D2;
  Double_t m_mc_ene_D1,m_mc_ene_D2;
  Int_t m_mc_process;
  //square ring regions
  Double_t m_def_SQR_xymin[NSQR],m_def_SQR_xymax[NSQR],m_def_SQR_zmin[NSQR],m_def_SQR_zmax[NSQR];
  Double_t m_mc_ene_SQR[NSQR],m_mc_max_ene_SQR[NSQR];  ;  
  Int_t m_mc_n_SQR[NSQR];
  Double_t m_ene_SQR[NSQR],m_max_ene_SQR[NSQR];  ;  
  Int_t m_n_SQR[NSQR];
  //compton
  Int_t m_co_seql,m_co_trl,m_co_hastr;
  Double_t m_co_dg[3],m_co_de[3],m_co_theta,m_co_phi,m_co_epsilon,m_co_eg,m_co_ee,m_co_arm,m_co_spd;
  Double_t m_co_deg,m_co_dee,m_co_dei,m_co_dphi;
  Double_t m_co_cqf,m_co_tqf,m_co_leverarm;
  Double_t m_co_c1[3],m_co_c2[3];
  Double_t m_co_trk_absprob,m_co_c2_absprob,m_co_c1_absprob,m_co_rl_along,m_co_rl_c1,m_co_rl_c2;
  Double_t m_co_nadirmax,m_co_nadirmax_rev;
  Double_t m_co_mcphi;
  //pair
  Double_t m_pp_angle,m_pp_dir_err,m_pp_dir[3],m_pp_p_dir[3],m_pp_e_dir[3];
  Double_t m_pp_tqf,m_pp_e_e,m_pp_e_p,m_pp_e_e_err,m_pp_e_p_err;


  //other
  MVector m_tmpvec,m_v1,m_v2,m_mcdir,m_gammadir;



};


#endif //__Storage__
